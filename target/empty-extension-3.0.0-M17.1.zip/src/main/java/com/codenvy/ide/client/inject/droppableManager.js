 function DroppableManager() {
	 alert("DropRecognized!!"); 

}